﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Collections;
using WindowsInput;
using System.Threading;

namespace AionScanner
{
    public partial class Form1 : Form
    {
        Process HandleP;

        //Foreground get and set are only imported because I am lazily using an active window to send events. Kill this when you re-wire

        [DllImport("user32.dll", EntryPoint = "SetForegroundWindow")]
        public static extern bool SetForegroundWindow(IntPtr hWnd);
        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();
        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool WriteProcessMemory(IntPtr hProcess, uint lpBaseAddress, byte[] lpBuffer, int nSize, out IntPtr lpNumberOfBytesWritten);


        
        // ByteSigScan convention.

        [DllImport("ByteSigScan.dll", EntryPoint = "InitializeSigScan", CallingConvention = CallingConvention.Cdecl)]
        public static extern void InitializeSigScan(uint iPID, [MarshalAs(UnmanagedType.LPStr)] string szModule);

        [DllImport("ByteSigScan.dll", EntryPoint = "SigScan", CallingConvention = CallingConvention.Cdecl)]
        public static extern UInt32 SigScan([MarshalAs(UnmanagedType.LPStr)] string Pattern, int Offset);

        [DllImport("ByteSigScan.dll", EntryPoint = "FinalizeSigScan", CallingConvention = CallingConvention.Cdecl)]
        public static extern void FinalizeSigScan();

        // Kernel dll convention.

        [DllImport("kernel32.dll", CallingConvention = CallingConvention.StdCall)]
        static extern IntPtr OpenProcess(ProcessAccessFlags dwDesiredAccess, [MarshalAs(UnmanagedType.Bool)] bool bInheritHandle, uint dwProcessId);
        [DllImport("kernel32.dll", SetLastError = true, CallingConvention = CallingConvention.StdCall)]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool CloseHandle(IntPtr hObject);
        [DllImport("kernel32.dll", SetLastError = true, CallingConvention = CallingConvention.StdCall)]
        static extern bool ReadProcessMemory(IntPtr hProcess, uint lpBaseAddress, ref uint lpBuffer, int dwSize, int lpNumberOfBytesRead);

        [DllImport("kernel32.dll", SetLastError = true, CallingConvention = CallingConvention.StdCall)]
        static extern bool ReadProcessMemory(IntPtr hProcess, uint lpBaseAddress, ref float lpBuffer, int dwSize, int lpNumberOfBytesRead);

        [DllImport("kernel32.dll", SetLastError = true, CallingConvention = CallingConvention.StdCall)]
        static extern bool ReadProcessMemory(IntPtr hProcess, uint lpBaseAddress, ref string lpBuffer, int dwSize, int lpNumberOfBytesRead);

        [DllImport("kernel32.dll", SetLastError = true, CallingConvention = CallingConvention.StdCall)]
        static extern bool ReadProcessMemory(IntPtr hProcess, uint lpBaseAddress, [Out] byte[] lpBuffer, int dwSize, int lpNumberOfBytesRead); 


        Thread healBotThread = new Thread(new ThreadStart(healBotMReader));

        Dictionary<string, int> timers = new Dictionary<string, int>();
        


        enum ProcessAccessFlags : uint
        {
            PROCESS_ALL_ACCESS = 0x001F0FFF,
            PROCESS_CREATE_THREAD = 0x00000002,
            PROCESS_DUP_HANDLE = 0x00000040,
            PROCESS_QUERY_INFORMATION = 0x00000400,
            PROCESS_SET_INFORMATION = 0x00000200,
            PROCESS_TERMINATE = 0x00000001,
            PROCESS_VM_OPERATION = 0x00000008,
            PROCESS_VM_READ = 0x00000010,
            PROCESS_VM_WRITE = 0x00000020,
            SYNCHRONIZE = 0x00100000
        }


        //uint currentPID = 0;
        uint gamedll = 0;
        string PISigTest = "00??????8B????68XXXXXXXX8D??3A??8D"; // Good, 2 Static references




        public Form1()
        {
            InitializeComponent();


            Process[] ProcessList = Process.GetProcesses();
            String ProcessName;
            int count = 0;

            pidBox.Items.Clear();
            for (int i = 0; i < ProcessList.Length; i++)
            {
                ProcessName = ProcessList[i].ProcessName;

                if (ProcessName == "AION.bin")
                {
                    int temp = ProcessList[i].MainWindowTitle.IndexOf("AION Client");
                    if ((ProcessList[i].MainWindowTitle.IndexOf("AION Client") > -1))
                    {


                        pidBox.Items.Add("AION.bin" + " - " + ProcessList[i].Id);
                        pidBox.SelectedIndex = 0;
                        HandleP = System.Diagnostics.Process.GetProcessById(ProcessList[i].Id);

                        foreach (System.Diagnostics.ProcessModule Module in HandleP.Modules)
                        {
                            if ("Game.dll" == Module.ModuleName)
                            {
                                count++;

                                if (count == Convert.ToInt32(cmbDll.Text))
                                {
                                    gamedll = (uint)Module.BaseAddress.ToInt32();
                                }

                            }
                        }
                    }
                }
            }
            
            //one time inits

            //add dictionary timer
            timers.Add("VK_1", 0);
            timers.Add("VK_2", 0);
            timers.Add("VK_3", 0);
            timers.Add("VK_4", 0);
            timers.Add("VK_5", 0);
            timers.Add("VK_6", 0);
            timers.Add("VK_7", 0);
            timers.Add("VK_8", 0);
            timers.Add("VK_9", 0);
            timers.Add("VK_0", 0);
            timers.Add("OEM_MINUS", 0);
            timers.Add("OEM_PLUS", 0);


            //initialize memory worker thread
            healBotThread.Start();

           
        }


        private void button1_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;
            button2.Enabled = true;

            string AionID = pidBox.Text;
            int AionIDPosition = AionID.IndexOf(" - ");
            AionID = AionID.Remove(0, AionIDPosition + 3);
            memory.currentPID = (uint)Convert.ToUInt32(AionID);
            //add h and s proc refs
            memory.sProc = OpenProcess(ProcessAccessFlags.PROCESS_ALL_ACCESS, false, memory.currentPID);
            memory.hProc = OpenProcess(ProcessAccessFlags.PROCESS_ALL_ACCESS, false, memory.currentPID);

            //perform pointer scan
            pointerScan("");
        }

        private void switchDll()
        {

            //this is just for handling multiple instances of the game dll you seem to have this resolved already
            int count = 0;

            string AionID = pidBox.Text;
            int AionIDPosition = AionID.IndexOf(" - ");
            AionID = AionID.Remove(0, AionIDPosition + 3);
            memory.currentPID = (uint)Convert.ToUInt32(AionID);

            HandleP = System.Diagnostics.Process.GetProcessById(Convert.ToInt32(memory.currentPID.ToString()));

            foreach (System.Diagnostics.ProcessModule Module in HandleP.Modules)
            {
                if ("Game.dll" == Module.ModuleName)
                {
                    count++;

                    if (count == Convert.ToInt32(cmbDll.Text))
                    {
                        gamedll = (uint)Module.BaseAddress.ToInt32();
                    }

                }
            }

            pointerScan("");

        }
        private void pidBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            button1.Enabled = true;
            button2.Enabled = false;
        }

        private void pointerScan(string type)
        {
            if (type != "party")
            {
                uint PITest = 0;

                    InitializeSigScan(memory.currentPID, "Game.dll");
                    PITest = SigScan(PISigTest, 0);
                    memory.playerInfoAddress = PITest;
                FinalizeSigScan();
            }

            uint lp1Party1 = 0;
            uint lp2Party1 = 0;
            uint lp3Party1 = 0;
            uint lp4Party1 = 0;
            uint lfinalParty1 = 0;

            //Here I am initially identifying the final party1 offset. All party info offsets are based on this.
            ReadProcessMemory(memory.hProc, gamedll + 0xC8FA64, ref lp1Party1, 4, 0);
            ReadProcessMemory(memory.hProc, lp1Party1 + 0x10, ref lp2Party1, 4, 0);
            ReadProcessMemory(memory.hProc, lp2Party1 + 0x40, ref lp3Party1, 4, 0);
            ReadProcessMemory(memory.hProc, lp3Party1 + 0x10, ref lp4Party1, 4, 0);
            ReadProcessMemory(memory.hProc, lp4Party1 + 0x8, ref lfinalParty1, 4, 0);

            memory.finalParty1 = lfinalParty1;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pointerScan("");

            //I was cleaning code and couldnt figure why I had these items here, they seem useless
            //txtLevel.Text = BitConverter.ToInt16(plvl, 1).ToString();
            //float pX = 0;
            //ReadProcessMemory(memory.hProc, lfinalParty1 + 0x2C, ref pX, 4, 0);

           

            if (WriteLoc.Checked == true)
            {
                //This is just for my testing new functions directly to mem... 
                //ignore it please

                /*
                uint memPosx1 = Convert.ToUInt32("4041247484");



                float xCord = float.Parse("563.803894");
                float yCord = float.Parse("2440.105713");
                float zCord = float.Parse("278.4933777");

                IntPtr nada = IntPtr.Zero;

                string test = "563.803894";
                 
                //IntPtr xaddr = 0xF0E08AFC;

                System.Text.ASCIIEncoding encoding = new System.Text.ASCIIEncoding();
                //Byte[] bytes = Encoding.GetBytes(test);
                 * */
                //WriteFloat(memory.hProc, "4041247484", 
                //static extern bool WriteProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, byte[] lpBuffer, UIntPtr nSize, out IntPtr lpNumberOfBytesWritten);
                //WriteProcessMemory(memory.hProc, , Buffer, Buffer.Length, out nada );
                //WriteProcessMemory(hand, (IntPtr)Address, data, (UIntPtr)data.Length, out bytesout);
                //ReadProcessMemory(memory.hProc, ptrtarget + target_x_offset, ref tgtxcord, 4, 0);

                /*
                byte[] x1Cord = BitConverter.GetBytes(float.Parse("563.803894"));
                byte[] y1Cord = BitConverter.GetBytes(float.Parse("2440.105713"));
                byte[] z1Cord = BitConverter.GetBytes(float.Parse("278.4933777"));
                byte[] x2Cord = BitConverter.GetBytes(float.Parse("563.803894"));
                byte[] y2Cord = BitConverter.GetBytes(float.Parse("2440.105713"));
                byte[] z2Cord = BitConverter.GetBytes(float.Parse("278.4933777"));
                byte[] walk = BitConverter.GetBytes(Convert.ToUInt32("2"));
                byte[] walk1 = BitConverter.GetBytes(Convert.ToUInt32("1"));
                
                
                WriteMe(memory.hProc, 0xF0E08AFC, x1Cord);
                WriteMe(memory.hProc, 0xF0E08B00, y1Cord);
                WriteMe(memory.hProc, 0xF0E08B04, z1Cord);
                WriteMe(memory.hProc, 0xF0E095B4, x2Cord);
                WriteMe(memory.hProc, 0xF0E095B8, y2Cord);
                WriteMe(memory.hProc, 0xF0E095BC, z2Cord);
                WriteMe(memory.hProc, 0xF0E08DA4, walk);
                WriteMe(memory.hProc, 0xF0E08AF8, walk1);

                 * */

                //timer1.Enabled = true;
                chbHealBot.CheckState = CheckState.Checked; //chbHealBot.Checked = true;

            }
        }

        public void WriteMe(IntPtr app, uint mAddress, byte[] Buffer)
        {
            //Ignore me.. personal testing
            IntPtr broken = IntPtr.Zero;
            try
            {

                WriteProcessMemory(app, mAddress, Buffer, Buffer.Length, out broken);
            }
            catch (Exception e)
            {
                Console.WriteLine("{0} Exception caught.", e);
            }
        }

        public static void WriteFloat(IntPtr app, long Address, float value)
        {
            //personal use ignore
            byte[] buffer = BitConverter.GetBytes(value);
            //WriteProcessMemory(app, (UIntPtr)Address, buffer, (UIntPtr)buffer.Length, IntPtr.Zero);
        }
        public static void WriteInt(IntPtr app, long Address, int value)
        {
            //personal use ignore
            byte[] buffer = BitConverter.GetBytes(value);
            //WriteProcessMemory(pHandle, (UIntPtr)Address, buffer, (UIntPtr)buffer.Length, IntPtr.Zero);
        }
        public static void WriteUInt(IntPtr app, long Address, uint value)
        {
            //personal use ignore
            byte[] buffer = BitConverter.GetBytes(value);
            //WriteProcessMemory(pHandle, (UIntPtr)Address, buffer, (UIntPtr)buffer.Length, IntPtr.Zero);
        }



        static void healBotMReader()
        {
            // this is a seperate thread that performs a read then pauses for 200ms
            // I created a globals section so we didnt need to worry about thread synch
            // its a bit dirty but we stay clean and light and since this is being read > 4 
            // times a second only minor variations will occur. 
            int a = 1;
            while (a == 1)
            {
                if (memory.threadState == "run")
                {

                    //local defines
                    float lpX = 0;
                    float lpY = 0;
                    float lpZ = 0;
                    float lXcord = 0;
                    float lYcord = 0;
                    float lZcord = 0;
                    uint lpMPCurr = 0;
                    uint lpHPCurr = 0;
                    uint lpHPTot = 0;
                    uint lpMPTot = 0;
                    uint lMyMPCurr = 0;
                    uint lMyHPCurr = 0;
                    uint lMyHPTot = 0;
                    uint lMyMPTot = 0;
                    uint lplvl = 0;
                    uint lcamrotate = 0;
                    byte[] lpName = new byte[32];
                    byte[] lmyName = new byte[32];


                    //read values from memory
                    ReadProcessMemory(memory.hProc, memory.finalParty1 + 0x30, ref lpX, 4, 0);
                    ReadProcessMemory(memory.hProc, memory.finalParty1 + 0x2C, ref lpY, 4, 0);
                    ReadProcessMemory(memory.hProc, memory.finalParty1 + 0x34, ref lpZ, 4, 0);
                    ReadProcessMemory(memory.hProc, memory.finalParty1 + 0x14, ref lpMPCurr, 4, 0);
                    ReadProcessMemory(memory.hProc, memory.finalParty1 + 0xC, ref lpHPCurr, 4, 0);
                    ReadProcessMemory(memory.hProc, memory.playerInfoAddress + memory.Player_HP_Offset, ref lMyHPCurr, 4, 0);
                    ReadProcessMemory(memory.hProc, memory.playerInfoAddress + memory.Player_MaxHP_Offset, ref lMyHPTot, 4, 0);
                    ReadProcessMemory(memory.hProc, memory.playerInfoAddress + memory.Player_MP_Offset, ref lMyMPCurr, 4, 0);
                    ReadProcessMemory(memory.hProc, memory.playerInfoAddress + memory.Player_MaxMP_Offset, ref lMyMPTot, 4, 0);
                    ReadProcessMemory(memory.hProc, memory.finalParty1 + 0x3a, ref lplvl, 1, 0);
                    ReadProcessMemory(memory.hProc, memory.finalParty1 + 0x8, ref lpHPTot, 4, 0);
                    ReadProcessMemory(memory.hProc, memory.finalParty1 + 0x10, ref lpMPTot, 4, 0);
                    ReadProcessMemory(memory.hProc, memory.finalParty1 + 0x3f, lpName, 32, 0);

                    ReadProcessMemory(memory.hProc, memory.playerInfoAddress - memory.Player_X_Offset, ref lXcord, 4, 0);
                    ReadProcessMemory(memory.hProc, memory.playerInfoAddress - memory.Player_Y_Offset, ref lYcord, 4, 0);
                    ReadProcessMemory(memory.hProc, memory.playerInfoAddress - memory.Player_Z_Offset, ref lZcord, 4, 0);
                    ReadProcessMemory(memory.hProc, memory.playerInfoAddress - memory.Cam_Rotate_Offset, ref lcamrotate, 4, 0);


                    //Check to see if address is valid
                    //Should probably find a better test

                    //write local values to global memory for use in other threads
                    memory.pX = lpX;
                    memory.pY = lpY;
                    memory.pZ = lpZ;
                    memory.Xcord = lXcord;
                    memory.Ycord = lYcord;
                    memory.Zcord = lZcord;
                    memory.pMPCurr = lpMPCurr;
                    memory.pHPCurr = lpHPCurr;
                    memory.pHPTot = lpHPTot;
                    memory.pMPTot = lpMPTot;
                    memory.plvl = lplvl.ToString();
                    memory.MyHPTot = lMyHPTot;
                    memory.MyHPCurr = lMyHPCurr;
                    memory.MyMPTot = lMyMPTot;
                    memory.MyMPCurr = lMyMPCurr;
                    memory.normDirection = normalize((int)lcamrotate);
                    memory.pName = getName(lpName);

                    //Determine Percentages, yeah I dont want to do a round here but its needed
                    //as I am using % eval in heal calcs which do not want to wait for main form
                    //timer to complete
                    float inta = ((float)memory.pMPTot);
                    float intb = ((float)memory.pMPCurr);
                    float intc = ((float)memory.pHPTot);
                    float intd = ((float)memory.pHPCurr);
                    float inte = ((float)memory.MyHPTot);
                    float intf = ((float)memory.MyHPCurr);
                    float intg = ((float)memory.MyMPTot);
                    float inth = ((float)memory.MyMPCurr);


                    memory.myMPPer = (int)Math.Round((inth / intg * 100));
                    memory.myHPPer = (int)Math.Round((intf / inte * 100));
                    memory.partyHPPer = (int)Math.Round((intd / intc * 100));
                    memory.partyMPPer = (int)Math.Round((intb / inta * 100));



                    //give the read a break
                    Thread.Sleep(200);
                }
                //thread is disabled... patiently wait for it to enable again
                Thread.Sleep(1000);
            }
            
        }

        public static string getName(byte[] playerName)
        {
            //string name = "";

            char[] chars = new char[playerName.Length / sizeof(char)];
            System.Buffer.BlockCopy(playerName, 0, chars, 0, playerName.Length);

            string name = new string(chars);

            return name;


        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //Very simply this timer is the refresh rate of data displayed on the winform. I slowed this down a bit

            
            if (memory.finalParty1 == 0 || memory.partyHPPer < 0 || memory.pMPTot > 3000000)
            {
                //if this happens, the player isnt in a group... continue as normal and refresh the pointers
                pointerScan("party");
                msgBox.Text = System.Environment.TickCount.ToString() + " (10) Cannot Find Party" + Environment.NewLine + msgBox.Text;
            }
            if (memory.myHPPer < 0)
            {
                //this means we arent getting player information and something is wrong... stop bot, notify user
                timer1.Enabled = false;
                memory.threadState = "";
                dgSkills.Enabled = true;
                msgBox.Text = System.Environment.TickCount.ToString() + " (12) Bot stopped: cant find your information" + Environment.NewLine + msgBox.Text;
                return;
            }

            try
            {
                txtLevel.Text = memory.plvl.ToString();
                txtMPCurrent.Text = memory.pMPCurr.ToString();
                txtHPCurrent.Text = memory.pHPCurr.ToString();
                txtX.Text = memory.pX.ToString();
                txtY.Text = memory.pY.ToString();
                txtZ.Text = memory.pZ.ToString();
                txtHPTotal.Text = memory.pHPTot.ToString();
                txtMPTot.Text = memory.pMPTot.ToString();
                txtHPPer.Text = memory.partyHPPer.ToString();
                txtName.Text = memory.pName;

                if (Convert.ToInt32(txtHPPer.Text) > 0)
                {
                    pbHP.Value = Convert.ToInt16(txtHPPer.Text);
                }
                txtMPPer.Text = memory.partyMPPer.ToString();
                if (Convert.ToInt32(txtMPPer.Text) > 0)
                {
                    pbMP.Value = Convert.ToInt32(txtMPPer.Text);

                }


                txtMyHPPer.Text = memory.myHPPer.ToString();
                if (Convert.ToInt32(txtMyHPPer.Text) > 0)
                {
                    pbMyHP.Value = Convert.ToInt16(txtMyHPPer.Text);
                }
                txtMyMPPer.Text = memory.myMPPer.ToString();
                if (Convert.ToInt32(txtMyMPPer.Text) > 0)
                {
                    pbMyMP.Value = Convert.ToInt32(txtMyMPPer.Text);

                }

                txtDistToPart.Text = distanceTo(memory.pX, memory.pY, memory.pZ, memory.Xcord, memory.Ycord, memory.Zcord).ToString();
            }
            catch
            {
                pointerScan("party");
                msgBox.Text = System.Environment.TickCount.ToString() + " (11) Cannot Find Party" + Environment.NewLine + msgBox.Text;
                return;
            }
                

            determineState();
            

        }

        private void chbHealBot_CheckedChanged(object sender, EventArgs e)
        {
            //enable/disable all functionality of the bot by startin/stopping the timer and thread
            if (chbHealBot.CheckState == CheckState.Checked)
            {
                timer1.Enabled = true;
                memory.threadState = "run";
                dgSkills.Enabled = false;
                
                //.Start()
            }
            else
            {
                timer1.Enabled = false;
                memory.threadState = "";
                dgSkills.Enabled = true;
                //healBotThread.Abort();
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            button2.PerformClick();
            
        }

       
        private int distanceTo(float x1, float y1, float z1, float x2, float y2, float z2)
        {

            //Get Distance between point 1 and 2
            //I know this is much faster using multiplication
            //Fixme when you have time
            float xd = 0;
            float yd = 0;
            float zd = 0;
            float math = 0;
            
            xd = x1 - x2;
            yd = y1 - y2;
            zd = z1 - z2;


            try
            {
                math = (float)Math.Sqrt(xd * xd + yd * yd + zd * zd);
                memory.Distance = (int)Math.Round(math);

                if (memory.Distance > -1)
                {
                    return memory.Distance;
                }
            }

            catch
            {
            }

            return -1;
        }

        private static int normalize(int facialDirection)
        {
            // convert the -180 to +180 rotation to true direction meaning 0 degrees is north for other calculations
            try
            {
                double normalfacialdirection = facialDirection + 180;

                return (int)normalfacialdirection;
            }
            catch
            {
                return -1;
            }

        }

        private void directionToTarget(float originX, float originY, float destinationX, float destinationY)
        {
            double radians;

            if (originX > destinationX && originY > destinationY)
            {
                radians = (Math.Atan((originX - destinationX) / (originY - destinationY))) * (180 / Math.PI) + 180;
            }
            else if (originX < destinationX && originY < destinationY)
            {
                radians = (Math.Atan((originX - destinationX) / (originY - destinationY))) * (180 / Math.PI);
            }
            else if (originX > destinationX && originY < destinationY)
            {
                radians = (Math.Atan((originY - destinationY) / (originX - destinationX) * -1)) * (180 / Math.PI) + 270;
            }
            else if (originX < destinationX && originY > destinationY)
            {
                radians = (Math.Atan((originY - destinationY) / (originX - destinationX) * -1)) * (180 / Math.PI) + 90;
            }
        }


        private void navigateTo(float x, float y, float z, int distBehind, float myZ)
        {
            double newX = 0;
            double newY = 0;
            double newZ = 0;

            int facialDirection = memory.normDirection;

            //This is the actual point in space -5 from wire your walk to functionality here (height cord is simply the difference between the current and actual)
            // the z cord is simply evenly the difference between player and party member as we are in a 3d plane at small dist, it should be close.
            if (facialDirection < 90)
            {
                newY = (double)y - (distBehind * (Math.Sin(((double)90 - (double)facialDirection) * Math.PI / 180)));
                newX = (double)x - (distBehind * (Math.Sin(((double)facialDirection) * Math.PI / 180)));
                newZ = (z + myZ) / 2; //hack
            }
            else if (facialDirection < 180)
            {
                newY = (double)y + (distBehind * (Math.Sin(((double)facialDirection - (double)90) * Math.PI / 180)));
                newX = (double)x - (distBehind * (Math.Sin(((double)180 - (double)facialDirection) * Math.PI / 180)));
                newZ = (z + myZ) / 2; //hack
            }
            else if (facialDirection < 270)
            {
                newY = (double)y + (distBehind * (Math.Sin(((double)270 - (double)facialDirection) * Math.PI / 180)));
                newX = (double)x + (distBehind * (Math.Sin(((double)facialDirection - (double)180) * Math.PI / 180)));
                newZ = (z + myZ) / 2; //hack
            }
            else if (facialDirection < 360)
            {
                newY = (double)y - (distBehind * (Math.Sin(((double)360 - (double)facialDirection) * Math.PI / 180)));
                newX = (double)x + (distBehind * (Math.Sin(((double)facialDirection - (double)270) * Math.PI / 180)));
                newZ = (z + myZ) / 2; //hack
            }

            //just for testing
            MessageBox.Show("Congrats, your new x should be " + newX.ToString() + " and y: " + newY.ToString() + " and z: " + newZ.ToString());
        }

        private void determineState()//applyLogic()
        {
            //msgBox.Text = System.Environment.TickCount.ToString() + " (i) Enter Determine State" + Environment.NewLine + msgBox.Text;
            string stype = "";
            string target = "";
            string condition = "";
            int value = 0;
            string key = "";
            bool chain = false;
            int cast = 0;
            int cooldown = 0;

            //Do every check to determine what is most important
            for (int rows = 0; rows < (dgSkills.Rows.Count -1); rows++)
            {

                for (int col = 0; col < dgSkills.Rows[rows].Cells.Count ; col++)
                {
                    //populate local var
                    try
                    {
                        stype = dgSkills.Rows[rows].Cells[0].Value.ToString();
                        target = dgSkills.Rows[rows].Cells[1].Value.ToString();
                        condition = dgSkills.Rows[rows].Cells[2].Value.ToString();
                        value = Convert.ToInt32(dgSkills.Rows[rows].Cells[3].Value.ToString());
                        key = dgSkills.Rows[rows].Cells[4].Value.ToString();
                        chain = Convert.ToBoolean(dgSkills.Rows[rows].Cells[5].FormattedValue.ToString());
                        cast = Convert.ToInt32(dgSkills.Rows[rows].Cells[6].Value.ToString());
                        cooldown = Convert.ToInt32(dgSkills.Rows[rows].Cells[7].Value.ToString());
                    }
                    catch
                    {
                        
                        timer1.Enabled = false;
                        //healBotThread.Abort();
                        memory.threadState = "";
                        chbHealBot.Checked = false;
                        MessageBox.Show("You have added an invalid value in the Skill List");
                        dgSkills.Enabled = true;
                        return;
                    }
                }
                //apply logic here

                //heal
                if (stype == "Heal")
                {
                    if (target == "Self")
                    {
                        //self
                        if (condition == "HP")
                        {
                            if (memory.myHPPer < value && timers[key] < System.Environment.TickCount)
                            {
                                //HP < Value and Cooldown expired then press Key
                                casting(target, key, chain, cast, cooldown, 0);

                            }
                        }
                        if (condition == "MP")
                        {
                            if (memory.myMPPer < value && timers[key] < System.Environment.TickCount)
                            {
                                //MP < Value and Cooldown expired then press Key
                                casting(target, key, chain, cast, cooldown, 0);
                            }
                        }
                    }
                    if (target == "Party")
                    {
                        //Party
                        if (memory.Distance < Convert.ToInt32(txtMaxDistance.Text))
                        {
                            if (condition == "HP")
                            {
                                if (memory.partyHPPer < value && timers[key] < System.Environment.TickCount)
                                {
                                    //HP < Value and Cooldown expired then press Key
                                    casting(target, key, chain, cast, cooldown, 0);

                                }
                            }
                            if (condition == "MP")
                            {
                                if (memory.partyMPPer < value && timers[key] < System.Environment.TickCount)
                                {
                                    //MP < Value and Cooldown expired then press Key
                                    casting(target, key, chain, cast, cooldown, 0);
                                }
                            }
                        }
                    }
                }
                if (stype == "Buff")
                {
                    //buff
                    if (target == "Self")
                    {
                        //self
                        if (timers[key] < System.Environment.TickCount)
                        {
                            //Cooldown expired then press Key
                            casting(target, key, chain, cast, cooldown, 0);
                        }
                    }
                    if (target == "Party")
                    {
                        //Party
                        if (timers[key] < System.Environment.TickCount)
                        {
                            //Cooldown expired 
                            if (memory.Distance < Convert.ToInt32(txtMaxDistance.Text))
                            {
                                //if distance < 20
                                casting(target, key, chain, cast, cooldown, 0);
                            }
                        }
                    }
                }
                

                //casting(target, key, chain, cast, cooldown, 0);

            }
            //msgBox.Text = System.Environment.TickCount.ToString() + " (i) Exit" + Environment.NewLine + msgBox.Text;

            //this entire section should only be walking(); once you have wired up movement to walking
            if (memory.Distance > Convert.ToInt16(txtMaxDist.Text))
            {
                if (memory.Distance < Convert.ToInt32(txtMaxDistance.Text))
                {
                    //walk damnit
                    if (memory.de_bug == true)
                    {
                        msgBox.Text = "Too Far: Current dist is " + memory.Distance.ToString() + " max distance is " + txtMaxDist.ToString() + Environment.NewLine + msgBox.Text;
                    }

                    walking();
                }
            }
        }

        private void walking()
        {
            //this entire method needs wired up to whatever you will be using.... for now just executing my follow target macro
            sendkey(VirtualKeyCode.F2);
            msgBox.Text = System.Environment.TickCount.ToString() + " (8) Select Party" + Environment.NewLine + msgBox.Text;
            System.Threading.Thread.Sleep(100);
            sendkey(VirtualKeyCode.VK_1);
            msgBox.Text = System.Environment.TickCount.ToString() + " (9) Follow Command" + Environment.NewLine + msgBox.Text;

        }

        private void casting(string target, string key, bool chain,int casttime, int cooldown, int chainTiers)
        {
            //lookup vkeycode to make it passable... yup i was lazy and not much time
            VirtualKeyCode kkkey = (VirtualKeyCode)System.Enum.Parse(typeof(VirtualKeyCode), key);
            VirtualKeyCode kktarget = VirtualKeyCode.F1;
            if (target == "Party")
            {
                kktarget = VirtualKeyCode.F2;
            }


            //VirtualKeyCode kktarget = (VirtualKeyCode)System.Enum.Parse(typeof(VirtualKeyCode), target);

            //if (HealMyHPFirstTick < System.Environment.TickCount)
            //    {
                    //select the target
                    sendkey(kktarget);
                    msgBox.Text = System.Environment.TickCount.ToString() + " (1) Selecting Target" + Environment.NewLine + msgBox.Text;

                

                    sendkey(kkkey);
                    msgBox.Text = System.Environment.TickCount.ToString() + " (2) Initial Send Key" + Environment.NewLine + msgBox.Text;
                    sendkey(kkkey); //sending a second time for shits and giggles
                    msgBox.Text = System.Environment.TickCount.ToString() + " (3) Final Send Key" + Environment.NewLine + msgBox.Text;
                    if (chain == true)
                    {
                        //heal chain
                        System.Threading.Thread.Sleep(3600);
                        sendkey(kkkey);
                        msgBox.Text = System.Environment.TickCount.ToString() + " (4) Heal Chain 1" + Environment.NewLine + msgBox.Text;
                        System.Threading.Thread.Sleep(200);
                        sendkey(kkkey);
                        msgBox.Text = System.Environment.TickCount.ToString() + " (5) Heal Chain 2" + Environment.NewLine + msgBox.Text;
                        System.Threading.Thread.Sleep(200);
                        sendkey(kkkey);
                        msgBox.Text = System.Environment.TickCount.ToString() + " (6) Heal Chain 3" + Environment.NewLine + msgBox.Text;
                        System.Threading.Thread.Sleep(200);
                        sendkey(kkkey);
                        msgBox.Text = System.Environment.TickCount.ToString() + " (7) Heal Chain 4" + Environment.NewLine + msgBox.Text;
                    }
                    //pause for casting
                    Thread.Sleep(casttime);

                    //start timer
                    //string temp = timers[key].ToString();
                    timers[key] = System.Environment.TickCount + cooldown;
                    //string temp2 = timers[key].ToString();
                    //Cast time  - pause for casting + 100 should be the timer value

                    //im done healing... follow again
                    walking();

                //}
        }

        private void skill(string skill)
        {

        }
        private void sendkey(VirtualKeyCode key)
        {
            //remove all this sendkey shit when you wire up walking
            if (GetForegroundWindow() != System.Diagnostics.Process.GetProcessById((int)memory.currentPID).MainWindowHandle)
            {
                SetForegroundWindow(System.Diagnostics.Process.GetProcessById((int)memory.currentPID).MainWindowHandle);
                System.Threading.Thread.Sleep(250);
            }
            //SetForegroundWindow(System.Diagnostics.Process.GetProcessById(6068).MainWindowHandle);
            InputSimulator.SimulateKeyPress(key);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //this is just testing
            //navigateTo((float)5.196,(float)3,218,60,10,(float)222.14);
            navigateTo((float)4, (float)4, 218, 3, (float)222.14);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            //close thread or no clean exit
            healBotThread.Abort();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            //I really have no idea how you transition state for isAttacked. 
        }

        private void cmbDll_SelectedIndexChanged(object sender, EventArgs e)
        {

            //remove when you port
            switchDll();
        }
    }
}
